// Start of my code that I did on my own. //
var distance;
var length;
var confLocs = [];
var confTheta = [];

function setup() {
    createCanvas(1000, 800, WEBGL);
	
    
    //sliders
    Confslider();
    Boxslider();
    Camslider();
    
    //step5: push confetti location and rotation angle to their array based on the slider value
    for(var i = 0; i < confettiSlider.value(); i++) {
        var xLoc = random(-500, 500);
        var yLoc = random(-800, 0);
        var zLoc = random(-500, 500);
        confLocs.push(createVector(xLoc, yLoc, zLoc));
        confTheta.push(random(0, 360));
    } 
}

function draw() {
    background(125);
    angleMode(DEGREES);
    
    var xLoc = cos((frameCount/5)*camSlider.value()) * 1200;
    var yLoc = sin((frameCount/5)*camSlider.value()) - 1000;
    var zLoc = sin((frameCount/5)*camSlider.value()) * 1200;
    camera(xLoc, yLoc, zLoc, 0, 0, 0, 0, 1, 0);
    
    
    confetti();
    
{	
	normalMaterial();
	stroke(0);
	strokeWeight(2);
	
	for(var i=0; i<16; i++)
    {
    	for(var j=0; j<16; j++)
	    {	
	    	distance = dist(50*i-400, 0, 50*j-400, 0, 0, 0)
	    	length = map(sin(distance+frameCount), -1, 1, 100, 300);

	    	push();
	    	translate(50*i-400, 0, 50*j-400)
            box(50, length+boxSlider.value()-300, 50);
	    	pop();
	    } 
    }
  }
}
    
function confetti() {
    normalMaterial();
    noStroke();
    
    //loop through the confettis based on the slider value
    for(var i = 0; i < confettiSlider.value(); i++) {
        push();
        translate(confLocs[i].x, confLocs[i].y, confLocs[i].z);
        rotateX(confTheta[i]);
        plane(15, 15);
        pop();
        
        //step 6: continue the rotation of the confettis
        confLocs[i].y += 1;
        confTheta[i] += 10;
        
        //if the confetti'y y value is more than 0, reset it to the top, -800
        if(confLocs[i].y > 0) {
            confLocs[i].y = -800;
        }
    }
}

function Confslider() {
    //confetti slider
    confettiSlider = createSlider(0, 200, 200);
    confettiSlider.position(0, 50)
    //get the element of the confetti slider
    var conf = document.getElementById("ConfSlider");
    confettiSlider.parent(conf);
    
    //make the html be the slider value
    var output = document.getElementById("confval");
    output.html = confettiSlider.value();
    
    //update the html based on the slider value oninput  ikuo u6
    conf.oninput = function() {
      output.innerHTML = confettiSlider.value();
    }
}

function Boxslider() {
    //cbox slider
    boxSlider = createSlider(300, 1000, 300);
    boxSlider.position(0, 100);
    
    //get the element of the box slider
    var box = document.getElementById("BoxSlider");
    boxSlider.parent(box);
    
    //make the html be the slider value
    var output = document.getElementById("boxval");
    output.html = boxSlider.value();
    
    //update the html based on the slider value oninput
    box.oninput = function() {
      output.innerHTML = boxSlider.value();
    }
}

function Camslider() {
    //camera slider
    camSlider = createSlider(-5, 5, 1, 0.5);
    camSlider.position(0, 150);
    
    //get the element of the camera slider
    var box = document.getElementById("CamSlider");
    camSlider.parent(box);
    
    //make the html be the slider value
    var output = document.getElementById("camval");
    output.html = camSlider.value();
    
    //update the html based on the slider value oninput
    box.oninput = function() {
      output.innerHTML = camSlider.value();
    }
}
// End of my code that I did on my own //